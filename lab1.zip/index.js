import express from 'express';
import bodyParser from 'body-parser';
import { USERS, ORDERS } from './db.js';
import { authorizationMiddleware } from './middlewares.js';

const app = express();

app.use(bodyParser.json());
/**
 * POST -- create resource
 * req -> input data
 * res -> output data
 */
app.post('/users', (req, res) => {
 const { body } = req;

 console.log(`body`, JSON.stringify(body));

 const isUserExist = USERS.some(el => el.login === body.login);
 if (isUserExist) {
  return res.status(400).send({ message: `user with login ${body.login} already exists` });
 }

 USERS.push(body);

 res.status(200).send({ message: 'User was created' });
});

app.get('/users', (req, res) => {
 const users = USERS.map(user => {
  const { password, ...other } = user;
  return other;
 });
 return res
  .status(200)
  .send(users);
});

app.post('/login', (req, res) => {
 const { body } = req;

 const user = USERS
  .find(el => el.login === body.login && el.password === body.password);

 if (!user) {
  return res.status(400).send({ message: 'User was not found' });
 }

 const token = crypto.randomUUID();

 user.token = token;
 USERS.save(user.login, { token });

 return res.status(200).send({
  token,
  message: 'User was login'
 });
});

app.post('/orders', authorizationMiddleware, (req, res) => {
 const { body, user} = req;
 
 const price = Math.floor(Math.random() * (100 - 20 + 1)) + 20;
 const order = {
  ...body,
  login: user.login,
  price
 };

 ORDERS.push(order);

 return res.status(200).send({ message: 'Order was created', order });
});





app.get('/orders', authorizationMiddleware, (req, res) => {
 const { user } = req;

 const orders = ORDERS.filter(el => el.login === user.login);

 return res.status(200).send(orders);
});




app.get('/orders/lowest', authorizationMiddleware, (req, res) =>{
   const {user} = req;

   if(!user){
    return res.status(400).send({massage: `User was not found by token: ${req.headers.authorization}`});
   }
   
   if(userOrders === 0){
    return res.status(400).send({massage: 'User has no orders'});
   }

   const lowestOrder = userOrders.reduce((lowest, order) =>{
    return order.price < lowest.price ? order : lowest;
   });

   res.status(200).send(lowestOrder);
});


app.get('/orders/biggest', authorizationMiddleware, (req, res) =>{
  const {user} = req;

  if(!user){
   return res.status(400).send({massage: `User was not found by token: ${req.headers.authorization}`});
  }
  
  if(userOrders === 0){
   return res.status(400).send({massage: 'User has no orders'});
  }

  const biggestOrder = userOrders.reduce((biggest, order) =>{
   return order.price > biggest.price ? order : biggest;
  });

  res.status(200).send(biggesttOrder);
});




app.get('/adress/from/last', authorizationMiddleware, (req, res) => {
  const count = req.query.count;
  const numberOfAdresses = parseInt(count);

  if (!numberOfAdresses || numberOfAdresses <= 0){
    return res.status(400).send({massage: "invalid count parameter"});
  }

  const userOrder = ORDERS.filter(order => order.login === req.user.login);
  const uniqueAdresses = [...new Set(userOrder.slice(-numberOfAdresses).map(order => order.from))];
  
  res.json(uniqueAdresses);
}); 



app.get('/adress/to/last', authorizationMiddleware, (req, res) => {
  const count = req.query.count;
  const numberOfAdresses = parseInt(count);

  if (!numberOfAdresses || numberOfAdresses <= 0){
    return res.status(400).send({massage: "invalid count parameter"});
  }

  const userOrder = ORDERS.filter(order => order.login === req.user.login);
  const uniqueAdresses = [...new Set(userOrder.slice(-numberOfAdresses).map(order => order.to))];
  
  res.json(uniqueAdresses);
}); 




app.listen(8080, () => console.log('Server was started'));